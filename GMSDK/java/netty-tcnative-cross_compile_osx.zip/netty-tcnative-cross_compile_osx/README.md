![Build project](https://github.com/netty/netty-tcnative/workflows/Build%20project/badge.svg)

## Tomcat Native Fork for Netty

See [our wiki page](http://netty.io/wiki/forked-tomcat-native.html).
